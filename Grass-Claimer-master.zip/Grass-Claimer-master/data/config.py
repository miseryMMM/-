THREADS = 1

# rpc https://www.quicknode.com/login
RPC_URL = 'https://greatest-summer-diagram.solana-mainnet.quiknode.pro/ea60cb220d957049e3e29fc07f34853f4d35313b'
DESTINATION_ADDRESS = ''

TIP_AMOUNT = 0.195  # 0.05 -> 1 in %
